# Phutility-s-SSOT-design-conceptualizer
Build scattered conflicting concepts into single truth
